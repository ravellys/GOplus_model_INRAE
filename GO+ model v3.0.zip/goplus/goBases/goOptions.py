
class goOptions:
    #defaults options
    FORCE_DECLARATIONS = False

