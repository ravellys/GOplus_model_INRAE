'''Add some scientific functions for modelisation'''


#common mathematic functions redefine from math module
from .goMath import *
